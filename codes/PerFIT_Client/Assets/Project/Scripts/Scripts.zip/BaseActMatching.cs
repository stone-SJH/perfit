﻿using UnityEngine;
using System.Collections;
using System.IO;
using System.Linq;
using System.Text;
using System;

public class BaseActMatching : MonoBehaviour {
	public DataManager dm;
	public GUIText myTextLeft;//GuiText for Left hand
	public GUIText myTextRight;//Pointer for Right hand

	protected double MaxDelta = 0.015;
	protected double deviation = 0.3;
	protected Status lhstatus = 0; // Left hand status
	protected Status rhstatus = 0; // Right hand status
	protected Status BestPerform = Status.Bad;

	protected int count = 0;
	protected Boolean IsDetecting = false;
	protected enum Status{
		Prepared = 0,
		Bad = 1,
		Good = 2,
		Great = 3,
		Done = 4,
		None
	}
	// Use this for initialization
	void Start () {
		dm = GameObject.Find ("DataManager").GetComponent<DataManager>();
	}
	
	// Update is called once per frame
	void Update () {
		try
		{
			for (int i = 0; i < dm.NumOfHands; i++) {
				string name = dm.gesture[i].gestureData.name;
				if (name.Equals("spreadfingers")){ 
					if (!IsDetecting) {
						count++;
						IsDetecting = true;
						myTextRight.text += string.Format("{0}: ",count);
						BestPerform = Status.Bad;
					}
				}else if ((name.Equals("fist") || name.Equals("full_pinch")) && IsDetecting){
					myTextRight.text += BestPerform.ToString();
					myTextRight.text += '\n';
					IsDetecting = false;
				}
					
				if (dm.hands.jointData != null) {
					getStatus(dm.hands.jointData[i], dm.hands.isLeft);
				}
			}
		}
		catch (IOException ex)
		{
			Console.WriteLine("An IOException has been thrown!");
			Console.WriteLine(ex.ToString());
			Console.ReadLine();
			return;
		}
	}

	protected virtual void getStatus(PXCMHandData.JointData[] data, bool isLeft){
		if (isLeft)
			lhstatus = checkMotion (data);
		else
			rhstatus = checkMotion (data);
	}

	protected virtual Status checkMotion(PXCMHandData.JointData[] data){
		if (isPrepared (data))
			return Status.Prepared;
		if (isBad (data))
			return Status.Bad;
		if (isGood (data))
			return Status.Good;
		if (isGreat (data))
			return Status.Great;
		if (isDone (data))
			return Status.Done;
		return Status.None;
	}

	protected virtual bool isPrepared(PXCMHandData.JointData[] data){
		return false;
	}
	protected virtual bool isBad(PXCMHandData.JointData[] data){
		return false;
	}
	protected virtual bool isGood(PXCMHandData.JointData[] data){
		return false;
	}
	protected virtual bool isGreat(PXCMHandData.JointData[] data){
		return false;
	}
	protected virtual bool isDone(PXCMHandData.JointData[] data){
		return false;
	}
}
