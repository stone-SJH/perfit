
using UnityEngine;
using System.Collections;
using System.IO;
using System.Linq;
using System.Text;
using System;

public class BaseArmMatching : BaseActMatching {
	[HideInInspector]
	public new PXCMArmData dm;
	protected Status lststatus = 0;

	// Use this for initialization
	void Start () {
		dm = GameObject.Find ("DataManager").GetComponent<PXCMArmData>();
	}
	
	// Update is called once per frame
	void Update () {
		lststatus = lhstatus;
		getStatus(dm.joints, true);
		if (lhstatus !=Status.None && lhstatus != Status.Done && lhstatus > BestPerform)
			BestPerform = lhstatus;
		if (lststatus == Status.Prepared && lhstatus != Status.Prepared) {
			myTextRight.text += string.Format("{0}: ",count++);
			BestPerform = Status.Bad;
			IsDetecting = false;
		}
		if (lststatus != Status.Done && lhstatus == Status.Done) {
			myTextRight.text += BestPerform.ToString();
			myTextRight.text += '\n';
			IsDetecting = true;
		}
	}
	
	#region Arm Data
	
	protected virtual void getStatus(PXCMArmData.JointData[] data, bool isLeft){}
	protected virtual Status checkMotion(PXCMArmData.JointData[] data){
		return Status.None;
	}
	protected virtual bool isPrepared(PXCMArmData.JointData[] data){
		return false;
	}
	protected virtual bool isBad(PXCMArmData.JointData[] data){
		return false;
	}
	protected virtual bool isGood(PXCMArmData.JointData[] data){
		return false;
	}
	protected virtual bool isGreat(PXCMArmData.JointData[] data){
		return false;
	}
	protected virtual bool isDone(PXCMArmData.JointData[] data){
		return false;
	}
	#endregion

}
