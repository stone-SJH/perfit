using UnityEngine;
using System.Collections;
using RSUnityToolkit;

public class SceneManager : MonoBehaviour {
	private int ArmScene = 3;
	private int HandScene = 2;
	public class Global
	{
		public static  MCTTypes.RunModes RunMode = MCTTypes.RunModes.RecordToFile;
		public static int SceneNum = 1;
	}

	public void GoBack()
	{
		Application.LoadLevel (1);
	}

	public void BeginArmRecording()
	{
		Global.RunMode = MCTTypes.RunModes.RecordToFile;
		Application.LoadLevel (ArmScene);
		Global.SceneNum = ArmScene;
	}

	public void BeginHandRecording()
	{
		Global.RunMode = MCTTypes.RunModes.RecordToFile;
		Application.LoadLevel (HandScene);
		Global.SceneNum = HandScene;
	}

	public void BeginAction(int SceneNum)
	{
		Global.RunMode = MCTTypes.RunModes.LiveStream;
//		GameObject ReverseButton2 = (GameObject)Instantiate (ReverseButton, Vector3.zero, Quaternion.identity);
//		DontDestroyOnLoad(ReverseButton);
		Application.LoadLevel (SceneNum);
	}

	public void BeginReplay()
	{
		Global.RunMode = MCTTypes.RunModes.PlayFromFile;
		Application.LoadLevel (Global.SceneNum);
		Debug.Log("replay!");
	}
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
}
